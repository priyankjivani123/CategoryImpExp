<?php

namespace Vdcstore\CategoryImpExpo\Controller\Adminhtml\Index;

use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\App\Filesystem\DirectoryList;

class Index extends \Magento\Framework\App\Action\Action
{
    protected $_pageFactory;
    protected $categoryFactory;
    protected $_storeManager;

    public function __construct(
        \Magento\Framework\App\Action\Context                           $context,
        \Magento\Framework\View\Result\PageFactory                      $pageFactory,
        \Magento\Catalog\Model\ResourceModel\Category\CollectionFactory $categoryFactory,
        \Magento\Store\Model\StoreManagerInterface                      $storeManager,
        \Magento\Framework\Filesystem                                   $filesystem,
        \Magento\Framework\App\Response\Http\FileFactory                $fileFactory
    )
    {
        $this->_pageFactory = $pageFactory;
        $this->_categoryFactory = $categoryFactory;
        $this->_storeManager = $storeManager;
        $this->fileFactory = $fileFactory;
        $this->directory = $filesystem->getDirectoryWrite(DirectoryList::VAR_DIR);
        return parent::__construct($context);
    }

    public function execute()
    {
        $collection = $this->_categoryFactory->create()->addAttributeToSelect('*')->setStore($this->_storeManager->getStore());
        $filepath = 'export/categoryexp.csv';
        $downloadedFileName = 'categoryexp.csv';
        $content['type'] = 'filename';
        $content['value'] = $filepath;
        $content['rm'] = 1;
        $this->directory->create('export');
        $stream = $this->directory->openFile($filepath, 'w+');
        $stream->lock();
        $header = ['entity_id', 'attribute_set_id', 'parent_id', 'created_at', 'updated_at', 'path', 'position', 'level', 'children_count', 'is_active', 'is_anchor', 'include_in_menu', 'name', 'display_mode', 'url_key', 'url_path'];
        
                
        $stream->writeCsv($header);
        foreach ($collection as $cat) {
            $getEntityid = $cat->getEntityid();
            $getAttributeSetId = $cat->getAttributeSetId();
            $getParentId = $cat->getParentId();
            $getCreatedAt = $cat->getCreatedAt();
            $getUpdatedAt = $cat->getUpdatedAt();
            $getPath = $cat->getPath();
            $getPosition = $cat->getPosition();
            $getChildrenCount = $cat->getChildrenCount();
            $getLevel = $cat->getLevel();
            $getIsActive = $cat->getIsActive();
            $getIsAnchor = $cat->getIsAnchor();
            $getIncludeInMenu = $cat->getIncludeInMenu();
            $getName = $cat->getName();
            $getDisplayMode = $cat->getDisplayMode();
            $getUrlKey = $cat->getUrlKey();
            $getUrlPath = $cat->getUrlPath();

            $data = [$getEntityid, $getAttributeSetId, $getParentId, $getCreatedAt, $getUpdatedAt, $getPath, $getPosition, $getChildrenCount, $getLevel, $getIsActive, $getIsAnchor, $getIncludeInMenu, $getName, $getDisplayMode, $getUrlKey, $getUrlPath];
            $stream->writeCsv($data);
        }
        return $this->fileFactory->create($downloadedFileName, $content, DirectoryList::VAR_DIR);
    }
}
