<?php

namespace Vdcstore\CategoryImpExpo\Controller\Adminhtml\Index;

use Magento\Framework\Exception\FileSystemException;
use Magento\Framework\Registry;
use Vdcstore\CategoryImpExpo\Block\System\Config\HelperData;
use Magento\Framework\Controller\ResultFactory;

class Import extends \Magento\Framework\App\Action\Action
{
    protected $_pageFactory;
    protected $StoreManagerInterface;
    protected $Category;
    protected $CategoryFactory;
    protected $file;
    protected $csv;
    private $registry;
    protected $categoryFactory;
    protected $helperdata;

    public function __construct(
        \Magento\Framework\App\Action\Context                           $context,
        \Magento\Framework\View\Result\PageFactory                      $pageFactory,
        \Magento\Store\Model\StoreManagerInterface                      $StoreManagerInterface,
        \Magento\Catalog\Model\Category                                 $Category,
        \Magento\Catalog\Model\CategoryFactory                          $CategoryFactory,
        \Magento\Framework\Filesystem\Driver\File                       $file,
        \Magento\Framework\File\Csv                                     $csv,
        \Magento\Catalog\Model\ResourceModel\Category\CollectionFactory $categoryFactory,
        HelperData                                                      $helperdata,
        \Magento\Framework\Filesystem\DirectoryList                     $DirectoryList,
        \Magento\Framework\Filesystem                                   $Filesystem,
        \Magento\Framework\Message\ManagerInterface                     $messageManager,
        ResultFactory                                                   $ResultFactory,
        Registry                                                        $registry
    )
    {
        $this->_pageFactory = $pageFactory;
        $this->helperdata = $helperdata;
        $this->StoreManagerInterface = $StoreManagerInterface;
        $this->Category = $Category;
        $this->file = $file;
        $this->csv = $csv;
        $this->CategoryFactory = $CategoryFactory;
        $this->registry = $registry;
        $this->_categoryFactory = $categoryFactory;
        $this->Filesystem = $Filesystem;
        $this->DirectoryList = $DirectoryList;
        $this->messageManager = $messageManager;
        $this->ResultFactory = $ResultFactory;

        return parent::__construct($context);
    }

    public function execute()
    {
        $this->importCategory();
        $resultRedirect = $this->ResultFactory->create(ResultFactory::TYPE_REDIRECT);
        
        $resultRedirect->setUrl($this->_redirect->getRefererUrl());
        return $resultRedirect;

    }

    public function getCategory($urlKey)
    {
        $categories = $this->CategoryFactory->create()->getCollection()
            ->addAttributeToFilter('url_key', $urlKey)
            ->addAttributeToSelect(['entity_id']);
        return $categories;
    }

    public function importCategory()
    {
        $getEnabl = $this->helperdata->getEnabl();
        $getCsvFileUploaddd = $this->helperdata->getCsvFileUploaddd();
        $filepath = $this->Filesystem->getDirectoryRead(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA)->getAbsolutePath();
        if ($getCsvFileUploaddd) {
            $csvFile = $filepath . "test/" . $getCsvFileUploaddd;
            $websiteId = $this->StoreManagerInterface->getWebsite()->getWebsiteId();
            $store = $this->StoreManagerInterface->getStore();
            $storeId = $store->getStoreId();
            $rootNodeId = $store->getRootCategoryId();
            $cat_info = $this->Category->load($rootNodeId);
            $categories = $this->CategoryFactory->create()->getCollection();

           
            if ($this->file->isExists($csvFile)) {
                $this->csv->setDelimiter(",");
                $data = $this->csv->getData($csvFile);
                $uploadedCsvHeader=$data[0];
                $header = ['entity_id', 'attribute_set_id', 'parent_id', 'created_at', 'updated_at', 'path', 'position', 'level', 'children_count', 'is_active', 'is_anchor', 'include_in_menu', 'name', 'display_mode', 'url_key', 'url_path'];
                if($uploadedCsvHeader==$header)
                 {  
                if (!empty($data)) {
                     $this->registry->register("isSecureArea", true);
                        foreach ($categories as $category) {
                            if ($category->getId() > 2) {
                                $category->delete();
                            }
                        }
                    foreach (array_slice($data, 3) as $key => $csvCategory) {
                        $entity_id = $csvCategory[0];
                        $attribute_set_id = $csvCategory[1];
                        $parent_id = $csvCategory[2];
                        $created_at = $csvCategory[3];
                        $updated_at = $csvCategory[4];
                        $path = $csvCategory[5];
                        $position = $csvCategory[6];
                        $level = $csvCategory[7];
                        $children_count = $csvCategory[8];
                        $is_active = $csvCategory[9];
                        $is_anchor = $csvCategory[10];
                        $include_in_menu = $csvCategory[11];
                        $name = $csvCategory[12];
                        $display_mode = $csvCategory[13];
                        $url_key = $csvCategory[14];
                        $url_path = $csvCategory[15];

                        $expload = explode('/', $url_path);
                        if (count($expload) > 1) {
                            $seconLastArray = $expload[count($expload) - 2];
                            $urlKey = $seconLastArray;
                            $category = $this->getCategory($urlKey);
                            $getCategoryData = $category->getData();
                            $entity_idOfCategory = $getCategoryData[0]['entity_id'];
                            $geUniqueEntity_idOfCategoryt = [];
                            foreach ($getCategoryData as $getCategoryData) {
                                $geUniqueEntity_idOfCategoryt[] = $getCategoryData['entity_id'];
                            }
                            foreach ($geUniqueEntity_idOfCategoryt as $uniqueEntityId) {
                                $entity_idOfCategory = $uniqueEntityId;
                            }
                            $categorys = array($name);
                            foreach ($categorys as $cat) {
                                $name = ucfirst($cat);
                                $url = strtolower($url_key);
                                $cleanurl = trim(preg_replace('/ +/', '', preg_replace('/[^A-Za-z0-9 ]/', '', urldecode(html_entity_decode(strip_tags($url_key))))));
                                $categoryTmp = $this->CategoryFactory->create();
                                $parentId = $entity_idOfCategory;
                                $parentCategory = $this->Category->load($parentId);
                                $categoryTmp->setPath($parentCategory->getPath());
                                $categoryTmp->setParentId($parentId);
                                $categoryTmp->setName($name);
                                if ($is_active == '1') {
                                    //set is active or not
                                    $categoryTmp->setIsActive(true);
                                } else {
                                    $categoryTmp->setIsActive(false);
                                }
                                //set include in menu or not
                                if ($include_in_menu == '1') {
                                    $categoryTmp->setIncludeInMenu(true);
                                } else {
                                    $categoryTmp->setIncludeInMenu(false);
                                }
                                $categoryTmp->setUrlKey($url_key);
                                $categoryTmp->setData('de4scription', 'description');
                                $categoryTmp->setParentId($this->Category->getId());
                                $categoryTmp->setStoreId($storeId);
                                $categoryTmp->save();
                               
                            }

                        } else {
                            $categorys = array($name);
                            foreach ($categorys as $cat) {
                                $name = ucfirst($cat);
                                $url = strtolower($url_key);
                                $cleanurl = trim(preg_replace('/ +/', '', preg_replace('/[^A-Za-z0-9 ]/', '', urldecode(html_entity_decode(strip_tags($url_key))))));
                                $categoryTmp = $this->CategoryFactory->create();
                                $parentId = $parent_id;
                                $parentCategory = $this->Category->load($parentId);
                                $categoryTmp->setPath($parentCategory->getPath());
                                $categoryTmp->setParentId($parentId);
                                $categoryTmp->setName($name);
                                if ($is_active == '1') {
                                    //set is active or not
                                    $categoryTmp->setIsActive(true);
                                } else {
                                    $categoryTmp->setIsActive(false);
                                }
                                //set include in menu or not
                                if ($include_in_menu == '1') {
                                    $categoryTmp->setIncludeInMenu(true);
                                } else {
                                    $categoryTmp->setIncludeInMenu(false);
                                }
                                $categoryTmp->setUrlKey($url_key);
                                $categoryTmp->setData('de4scription', 'description');
                                $categoryTmp->setParentId($this->Category->getId());
                                $categoryTmp->setStoreId($storeId);
                                $categoryTmp->save();
                                
                            }
                        }

                    }
                }
                 $message = 'Import Successfully';
                                 $this->messageManager->addSuccessMessage($message);
            }
            else{
          $message = 'Make Sure You Selected Category Csv File';
            $this->messageManager->addErrorMessage($message);
             }
        } else {
            $message = 'Make Sure You Upploaded Csv File';
            $this->messageManager->addErrorMessage($message);

        }
    }
}
}
