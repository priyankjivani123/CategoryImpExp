<?php

namespace Vdcstore\CategoryImpExpo\Block\System\Config;

class HelperData extends \Magento\Framework\View\Element\Template
{
    protected $serializer;

    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Vdcstore\CategoryImpExpo\Helper\Data            $helperdata,
        \Magento\Framework\Serialize\SerializerInterface $serializer,
        array                                            $data = []
    )
    {
        parent::__construct($context, $data);
        $this->serializer = $serializer;
        $this->helperdata = $helperdata;

    }

    public function getCsvFileUploaddd()
    {
        return $this->helperdata->getGeneralConfig('csv_file_uploaddd');
    }

    public function getEnabl()
    {
        return $this->helperdata->getGeneralConfig('enable');
    }

}
